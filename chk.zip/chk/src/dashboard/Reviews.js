import React, { useState } from 'react';
import kbc from '../images/kbc-prep.jpeg';
import class2to5 from '../images/grad2-5.jpeg';
import class6to10 from '../images/grad6-10.jpeg';

const coursesData = [
  {
    id: 1,
    title: 'Maths Genius Level 2-5',
    logo: class2to5,
  },
  {
    id: 2,
    title: 'Maths Genius Level 6-10',
    logo: class6to10,
  },
  {
    id: 3,
    title: 'KBC Genius Level Quiz',
    logo: kbc,
  },
];

const Review = () => {
  const [ratings, setRatings] = useState({}); // Track ratings for each course
  const [thumbs, setThumbs] = useState({}); // Track thumbs for each course
  const [message, setMessage] = useState('');

  const handleStarClick = (courseId, rating) => {
    setRatings((prev) => ({ ...prev, [courseId]: rating }));
    setMessage(`You rated ${rating} star(s) for Course ID ${courseId}`);
  };

  const handleThumbsClick = (courseId, type) => {
    if (thumbs[courseId] === type) {
      setThumbs((prev) => ({ ...prev, [courseId]: null })); // Remove the thumb if the same button is clicked
      setMessage('');
    } else {
      setThumbs((prev) => ({ ...prev, [courseId]: type }));
      setMessage(`You clicked thumbs ${type === 'up' ? 'up' : 'down'} for Course ID ${courseId}`);
    }
  };

  const styles = {
    container: {
      padding: '20px',
    },
    courseCards: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '20px',
    },
    courseCard: {
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px',
      width: '200px',
      textAlign: 'center',
    },
    courseLogo: {
      width: '100%',
      height: 'auto',
    },
    starRating: {
      display: 'flex',
      justifyContent: 'center',
      cursor: 'pointer',
    },
    star: {
      fontSize: '24px',
      color: 'gray',
    },
    filledStar: {
      color: '#ff5248', // Highlighted color
    },
    thumbsContainer: {
      marginTop: '10px',
    },
    thumbsBtn: {
      background: 'none',
      border: 'none',
      fontSize: '24px',
      cursor: 'pointer',
      padding: '0 10px',
    },
    activeThumb: {
      color: '#ff5248', // Highlight color when active
    },
    feedbackMessage: {
      color: '#333',
      marginBottom: '10px',
    },
  };

  return (
    <div style={styles.container}>
      <h1>Course Reviews</h1>
      {message && <p style={styles.feedbackMessage}>{message}</p>}
      <div style={styles.courseCards}>
        {coursesData.map((course) => (
          <div style={styles.courseCard} key={course.id}>
            <img src={course.logo} alt={`${course.title} logo`} style={styles.courseLogo} />
            <h3>{course.title}</h3>
            <div style={styles.starRating}>
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  style={{
                    ...styles.star,
                    ...(ratings[course.id] >= star ? styles.filledStar : {}),
                  }}
                  onClick={() => handleStarClick(course.id, star)}
                >
                  ★
                </span>
              ))}
            </div>
            <div style={styles.thumbsContainer}>
              <button
                style={{
                  ...styles.thumbsBtn,
                  ...(thumbs[course.id] === 'up' ? styles.activeThumb : {}),
                }}
                onClick={() => handleThumbsClick(course.id, 'up')}
              >
                👍
              </button>
              <button
                style={{
                  ...styles.thumbsBtn,
                  ...(thumbs[course.id] === 'down' ? styles.activeThumb : {}),
                }}
                onClick={() => handleThumbsClick(course.id, 'down')}
              >
                👎
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Review;
