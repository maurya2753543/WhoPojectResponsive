import React, { useEffect, useState } from 'react';
import notificationService from '../service/NotificationService'; // Import the service
import './ShowNotification.css'; // Assuming you have styles here

const ShowNotification = () => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setNotifications(notificationService.getNotifications());
    }, 1000); // Refresh notifications every second

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  return (
    <div className="notification-marquee">
      {notifications.length > 0 ? (
        notifications.map((notification, index) => (
          <span key={index} className="notification-text">
            {notification} &nbsp; &nbsp; {/* Separator */}
          </span>
        ))
      ) : (
        <span className="notification-text">Exciting News Our new course has a ★★★★★ rating!
         Don’t miss out on this incredible offer! 
         Huge Discounts Inside — Hurry, Limited Time Offer!</span>
      )}
    </div>
  );
};

export default ShowNotification;
