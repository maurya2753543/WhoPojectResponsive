// src/components/TopStudentsGallery.js

import React from 'react';
import Slider from 'react-slick';
import './TopStudentsGallery.css'; // Ensure this file contains the necessary styles
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css"; 

const studentData = [
    { imgSrc: require('../images/student1.jpeg'), alt: 'Student 1', caption: 'Aditi Jha -Noida' },
    { imgSrc: require('../images/student2.jpeg'), alt: 'Student 2', caption: 'Amit Pal  -Gurugram' },
    { imgSrc: require('../images/student3.jpeg'), alt: 'Student 3', caption: 'Rahul Sigh - Kanpur' },
    { imgSrc: require('../images/student4.jpeg'), alt: 'Student 4', caption: 'Aadhya Maurya -Greater-Noida' },
    { imgSrc: require('../images/student5.jpeg'), alt: 'Student 1', caption: 'Kaysav Patil - Delhi' },
    { imgSrc: require('../images/student6.jpeg'), alt: 'Student 2', caption: 'Mohan Patel - Mumbai' },
]

const TopStudentsGallery = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: true,
    nextArrow: <button className="slick-next">Next</button>,
    prevArrow: <button className="slick-prev">Previous</button>,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <div className="top-students-gallery">
      <h2><span className="gallery-title">Top Students</span></h2>
      <Slider {...settings}>
        {studentData.map((item, index) => (
          <div key={index} className="student-item">
            <img
              src={item.imgSrc}
              alt={item.alt}
              className="img-fluid"
            />
            <div className="student-caption">{item.caption}</div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default TopStudentsGallery;
