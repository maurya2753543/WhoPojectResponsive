import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as d3 from 'd3';

const BubbleChartDemographics = () => {
  const chartRef = useRef(null);
  const [scoreType, setScoreType] = useState('Pre Score');
  const [data, setData] = useState(null);
  const [attempts, setAttempts] = useState([]);

  const width = chartRef.current ? chartRef.current.clientWidth : 800; // Default width
  const height = 400;
  const bubbleColors = ['#A174FF', '#6F1CEC', '#390D95'];
  const arcColors = ['#00D58B', '#357FF5'];
  const legendValues = ['Pre Score', 'Post Score'];

  const getData = () => ({
    children: [
      { name: 'Diamond', value: 150, preScore: 50, postScore: 80 },
      { name: 'Foundation', value: 108, preScore: 60, postScore: 90 },
      { name: 'Aerospace', value: 150, preScore: 30, postScore: 70 },
      { name: 'Retail', value: 100, preScore: 170, postScore: 120 },
      { name: 'Diamond', value: 100, preScore: 250, postScore: 80 },
    
    ],
  });

  const getAttempts = () => [
    { courseName: 'Diamond', attempts: 5 },
    { courseName: 'Foundation', attempts: 3 },
    { courseName: 'Aerospace', attempts: 2 },
    { courseName: 'Retail', attempts: 4 },
  ];

  const processData = useCallback(() => {
    const fetchedData = getData();
    fetchedData.children.forEach(element => {
      element.displayValue = element.value;
    });
    setData(fetchedData);
    setAttempts(getAttempts());
  }, []);

  const renderSVG = useCallback(() => {
    const chartElement = chartRef.current;
    if (!chartElement) return null;

    d3.select(chartElement).select('svg').remove(); // Clear existing SVG
    return d3.select(chartElement)
      .append('svg')
      .attr('class', 'bubble')
      .attr('viewBox', `0 0 ${width} ${height}`);
  }, [width, height]);

  const drawChart = useCallback(() => {
    const svg = renderSVG();
    if (!svg || !data) return;
    
    svg.selectAll('*').remove(); // Clear existing chart
    drawChartLegends(svg);
    prepareHierarchalData(svg);
    generateBubbles(svg);
    renderTooltip(svg);
  }, [renderSVG, data, scoreType]);

  useEffect(() => {
    processData();
    window.addEventListener('resize', drawChart);
    return () => window.removeEventListener('resize', drawChart);
  }, [processData, drawChart]);

  useEffect(() => {
    if (data) {
      drawChart();
    }
  }, [data, drawChart]);

  const drawChartLegends = (svg) => {
    const legend = svg.append('g').attr('class', 'legend-c');
    const legendGroup = legend.selectAll('.legend')
      .data(legendValues)
      .enter()
      .append('g');

    const size = 6;
    const gap = 10;
    const textColor = '#0F0F0F';

    legendGroup.append('circle')
      .attr('class', 'legend-shape')
      .attr('r', size)
      .style('fill', (d, i) => arcColors[i]);
      

    legendGroup.append('text')
      .attr('class', 'legend-label')
      .attr('x', size + 2)
      .attr('y', size)
      .attr('dy', '-0.4em')
      .style('fill', textColor)
      .text(d => d)
      .style('font-family', 'Graphik')
      .style('font-weight', 400)
      .style('font-size', 12)
      .style('text-anchor', 'center')
      .style('alignment-baseline', 'middle');

    legendGroup.attr('transform', (d, i) => `translate(${d3.sum(legendValues, (e, j) => (j < i ? legendGroup.nodes()[j].getBBox().width : 0)) + gap * i},${10})`);
    legend.attr('transform', 'translate(10, 0)');
  };

  const prepareHierarchalData = (svg) => {
    if (!data) {
      console.error('Data is not available for preparing hierarchical data.');
      return;
    }

    const bubble = d3.pack().size([width, height]).padding(20);
    const nodes = d3.hierarchy(data).sum(d => {
      const value = scoreType === 'Pre Score' ? d.preScore : d.postScore;
      return value < 5 ? 50 : value < 50 ? 70 : value < 100 ? 90 : value < 500 ? 100 : 120;
    });

    const node = svg.selectAll('.node')
      .data(bubble(nodes).descendants())
      .enter()
      .filter(d => !d.children);

    node.append('g')
      .attr('class', 'node')
      .attr('transform', d => `translate(${d.x},${d.y})`);
  };

  const generateBubbles = (svg) => {
    const circles = svg.selectAll('.node');

    circles.append('circle')
      .attr('r', d => d.r - 5)
      .style('fill', (d, i) => bubbleColors[i])
      .on('mouseover', mouseOver)
      .on('mousemove', mouseMove)
      .on('mouseout', mouseOut);

    circles.append('text')
      .attr('dy', '-0.2em')
      .style('text-anchor', 'middle')
      .style('font-family', 'Graphik')
      .style('font-weight', 400)
      .style('font-size', 17)
      .style('fill', '#FFFFFF')
      .text(d => d.data.displayValue);

    circles.append('text')
      .attr('dy', '1.2em')
      .style('text-anchor', 'middle')
      .style('font-weight', 'bold') // Bold text

      .style('font-family', 'Graphik')
      .style('font-weight', 400)
      .style('font-size', 17)
      .style('fill', '#FFFFFF')
    //  .text(d => d.data.name.substring(0, d.r / 3));
  };

  const mouseOver = (event, d) => {
    const attemptsData = attempts.find(attempt => attempt.courseName === d.data.name);
    const scoreText = `${scoreType}: ${d.data.value}\nAttempts: ${attemptsData ? attemptsData.attempts : 0}`;

    d3.select('#tooltipText').text(scoreText).style('visibility', 'visible')
      .attr('transform', `translate(${event.offsetX - 21}, ${event.offsetY - 35})`);
  };

  const mouseMove = (event) => {
    d3.select('#tooltipText').attr('transform', `translate(${event.offsetX - 21}, ${event.offsetY - 35})`);
  };

  const mouseOut = () => {
    d3.select('#tooltipText').style('visibility', 'hidden');
  };

  const renderTooltip = (svg) => {
    const tooltipGroup = svg.append('g').attr('id', 'tooltip_group').style('position', 'absolute').style('fill', 'none');
    tooltipGroup.append('path')
      .attr('id', 'tooltipPath')
      .attr('d', 'M6,29H19l2.1,4.4a.992.992,0,0,0,1.3.5,1.205,1.205,0,0,0,.5-.5l2-4.4h13a6.018,6.018,0,0,0,6-6V6a6.018,6.018,0,0,0-6-6H6A6.018,6.018,0,0,0,0,6V23A6.018,6.018,0,0,0,6,29Z')
      .attr('fill', '#5a5a5a')
      .attr('visibility', 'hidden');

    svg.append('g')
      .attr('id', 'tooltipText_group')
      .style('position', 'absolute')
      .style('fill', 'none')
      .append('text')
      .attr('id', 'tooltipText')
      .attr('fill', '#FFFFFF')
      .attr('visibility', 'hidden')
      .style('font-family', 'Graphik')
      .style('font-weight', 400)
      .style('font-weight', 'bold') // Bold text
      .style('font-size', 16)
      .text('');
  };

  return (
    <div>
            <h2 style={{margin : '40px' , padding : '20px' , color : 'white'}}>Analyzing Attempts: Pre-Quiz vs. Post-Quiz Performance</h2>

      <div style={{ textAlign: 'center', marginBottom: '10px' }}>
      <button
        onClick={() => setScoreType('Pre Score')}
        style={{
          padding: '10px 20px',
          margin: '0 5px',
          border: '1px solid #ccc',
          borderRadius: '5px',
          backgroundColor: scoreType === 'Pre Score' ? '#007bff' : '#f0f0f0',
          color: scoreType === 'Pre Score' ? '#fff' : '#333',
          cursor: 'pointer',
          transition: 'background-color 0.3s, color 0.3s'
        }}
      >
        Show Pre Score
      </button>
      <button
        onClick={() => setScoreType('Post Score')}
        style={{
          padding: '10px 20px',
          margin: '0 5px',
          border: '1px solid #ccc',
          borderRadius: '5px',
          backgroundColor: scoreType === 'Post Score' ? '#007bff' : '#f0f0f0',
          color: scoreType === 'Post Score' ? '#fff' : '#333',
          cursor: 'pointer',
          transition: 'background-color 0.3s, color 0.3s'
        }}
      >
        Show Post Score
      </button>
    </div>

      <div ref={chartRef}></div>
    </div>
  );
};

export default BubbleChartDemographics;
