import React, { useEffect, useState } from 'react';
import * as d3 from 'd3';

const BarGraphStacked = () => {
  const [data, setData] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('Course A');
  const [selectedTitle, setSelectedTitle] = useState('Title 1');
  
  const courses = ['Course A', 'Course B', 'Course C'];
  const titles = ['Title 1', 'Title 2', 'Title 3'];

  const margin = { top: 30, right: 20, bottom: 30, left: 40 };
  const width = 600 - margin.left - margin.right;
  const height = 400 - margin.top - margin.bottom;

  const keys = ['Defect', 'Flag', 'Good'];
  const colors = ['black', 'darkgrey', 'grey'];

  const getData = () => {
    return [
      { month: 'Aug', Course: 'Course A', Defect: 10, Flag: 30, Good: 40 },
      { month: 'Sep', Course: 'Course A', Defect: 90, Flag: 50, Good: 60 },
      { month: 'Oct', Course: 'Course A', Defect: 120, Flag: 100, Good: 80 },
      { month: 'Nov', Course: 'Course A', Defect: 130, Flag: 50, Good: 120 },
      { month: 'Dec', Course: 'Course A', Defect: 200, Flag: 80, Good: 100 },
      { month: 'Jan', Course: 'Course A', Defect: 160, Flag: 90, Good: 80 },
      { month: 'Aug', Course: 'Course B', Defect: 20, Flag: 40, Good: 50 },
      { month: 'Sep', Course: 'Course B', Defect: 80, Flag: 60, Good: 70 },
      { month: 'Oct', Course: 'Course B', Defect: 90, Flag: 80, Good: 90 },
      { month: 'Nov', Course: 'Course B', Defect: 100, Flag: 70, Good: 60 },
      { month: 'Dec', Course: 'Course B', Defect: 110, Flag: 90, Good: 40 },
      { month: 'Jan', Course: 'Course B', Defect: 130, Flag: 100, Good: 30 },
      { month: 'Aug', Course: 'Course C', Defect: 30, Flag: 20, Good: 40 },
      { month: 'Sep', Course: 'Course C', Defect: 40, Flag: 30, Good: 50 },
      { month: 'Oct', Course: 'Course C', Defect: 60, Flag: 50, Good: 80 },
      { month: 'Nov', Course: 'Course C', Defect: 70, Flag: 90, Good: 100 },
      { month: 'Dec', Course: 'Course C', Defect: 80, Flag: 110, Good: 120 },
      { month: 'Jan', Course: 'Course C', Defect: 90, Flag: 130, Good: 140 },
    ];
  };

  const filterData = () => {
    const filteredData = getData().filter(d => d.Course === selectedCourse);
    setData(filteredData);
  };

  useEffect(() => {
    filterData();
  }, [selectedCourse, selectedTitle]);

  useEffect(() => {
    drawStackedGraph();
  }, [data]);

  const stacks = () => {
    return d3.stack().keys(keys)(data);
  };

  const drawStackedGraph = () => {
    d3.select('#bar-graph-stacked').selectAll('*').remove();

    const svg = d3.select('#bar-graph-stacked')
      .append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const xScale = d3.scaleBand()
      .domain(data.map(d => d.month))
      .range([0, width])
      .padding(0.1);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(stacks().flat(2))])
      .range([height, 0]);

    const xAxis = d3.axisBottom(xScale);
    const yAxis = d3.axisLeft(yScale).ticks(5);

    svg.append('g')
      .attr('class', 'axis axis--x')
      .attr('transform', `translate(0,${height})`)
      .call(xAxis)
      .selectAll('text')
      .style('font-size', '10px');

    svg.append('g')
      .attr('class', 'axis axis--y')
      .call(yAxis)
      .selectAll('text')
      .style('font-size', '10px')
      .style('font-weight', 'bold')
      .style('fill', 'black');

    const layer = svg.selectAll('.layer')
      .data(stacks())
      .enter().append('g')
      .attr('class', 'layer')
      .style('fill', (d, i) => colors[i]);

    layer.selectAll('rect')
      .data(d => d)
      .enter().append('rect')
      .attr('x', d => xScale(d.data.month))
      .attr('y', d => yScale(d[1]))
      .attr('height', d => yScale(d[0]) - yScale(d[1]))
      .attr('width', xScale.bandwidth())
      .on('mouseover', (event, d) => {
        const courseTitle = d.data.Course;
        const score = d[1] - d[0];
        d3.select('#tooltip')
          .style('opacity', 1)
          .html(`Course: ${courseTitle}<br/>Score: ${score}`)
          .style('left', `${event.pageX}px`)
          .style('top', `${event.pageY - 28}px`);
      })
      .on('mouseout', () => {
        d3.select('#tooltip').style('opacity', 0);
      });
  };

  return (
    <div style={{marginLeft : '20px'}}>
      <h2 style={{margin : '40px' , padding : '20px' , color : 'white'}}>Course Performance Scoreboard</h2>
      <div style={{ display: 'flex', justifyContent: 'space-between' , padding : '20px' , width : "90%" }}>
        <select value={selectedCourse} onChange={e => setSelectedCourse(e.target.value)} style={{ flex: '1', marginRight: '10px' }}>
          {courses.map(course => <option key={course} value={course}>{course}</option>)}
        </select>
        <select value={selectedTitle} onChange={e => setSelectedTitle(e.target.value)} style={{ flex: '1', marginLeft: '10px' }}>
          {titles.map(title => <option key={title} value={title}>{title}</option>)}
        </select>
      </div>
      <div id="bar-graph-stacked"></div>
      <div id="tooltip" style={{ position: 'absolute', opacity: 0, background: 'lightgrey', border: '1px solid black', padding: '5px' }} />
    </div>
  );
};

export default BarGraphStacked;
