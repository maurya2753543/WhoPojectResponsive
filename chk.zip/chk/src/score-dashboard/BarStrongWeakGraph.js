import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as d3 from 'd3';

const BubbleChartDemographics = () => {
  const chartRef = useRef(null);
  const [tooltipData, setTooltipData] = useState(null);

  const width = 400;
  const height = 400;
  const radius = Math.min(width, height) / 2;
  const color = d3.scaleOrdinal(['#4CAF50', '#FF9800', '#F44336', '#2196F3', '#9C27B0']);

  // Static data for skills and scores
  const data = [
    { name: 'Skill A', score: 90 },
    { name: 'Skill B', score: 60 },
    { name: 'Skill C', score: 80 },
    { name: 'Skill D', score: 40 },
    { name: 'Skill E', score: 30 },
  ];

  // Create arc only once, using useCallback to prevent unnecessary recreation
  const createArc = useCallback(() => {
    const totalScore = d3.sum(data, d => d.score);
    const arc = d3.arc().innerRadius(0).outerRadius(radius);
    const pie = d3.pie().value(d => d.score);

    // Clear any existing SVG to prevent multiple circles on re-render
    d3.select(chartRef.current).selectAll('*').remove();

    // Create SVG container
    const svg = d3.select(chartRef.current).append('svg')
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    // Create arcs for each data point
    const arcs = svg.selectAll('g.arc')
      .data(pie(data))
      .enter()
      .append('g')
      .attr('class', 'arc');

    // Append paths for each arc
    arcs.append('path')
      .attr('d', arc)
      .attr('fill', (d, i) => color(i))
      .attr('stroke', 'white')
      .attr('stroke-width', 2)
      .on('mouseover', (event, d) => {
        const percentage = ((d.data.score / totalScore) * 100).toFixed(1) + '%';
        setTooltipData({
          name: d.data.name,
          percentage,
          x: event.pageX,
          y: event.pageY,
        });
      })
      .on('mousemove', (event) => {
        setTooltipData((prev) => prev && { ...prev, x: event.pageX, y: event.pageY });
      })
      .on('mouseout', () => setTooltipData(null));

    // Append text for score percentage inside each arc
    arcs.append('text')
      .attr('transform', d => `translate(${arc.centroid(d)})`)
      .attr('text-anchor', 'middle')
      .style('fill', 'white')
      .style('font-size', '12px')
      .text(d => `${((d.data.score / totalScore) * 100).toFixed(1)}%`);
  }, [data, color]);

  // Only call createArc on component mount or when createArc changes
  useEffect(() => {
    createArc();
  }, [createArc]);

  return (
    <div style={{ position: 'relative', width: '400px', margin: 'auto' }}>
      <h2 style={{ textAlign: 'center', color: 'white' }}>Skill Scores</h2>
      <div ref={chartRef} style={{ width: '100%', height: '400px' }} />

      {/* Tooltip only displays on hover */}
      {tooltipData && (
        <div
          style={{
            position: 'absolute',
            top: tooltipData.y - 50,
            left: tooltipData.x - 20,
            background: 'rgba(0, 0, 0, 0.8)',
            color: 'white',
            padding: '10px',
            borderRadius: '6px',
            pointerEvents: 'none',
            fontSize: '16px',
            fontWeight: 'bold',
          }}
        >
          <div>{tooltipData.name}</div>
          <div>{tooltipData.percentage}</div>
        </div>
      )}
    </div>
  );
};

export default BubbleChartDemographics;
