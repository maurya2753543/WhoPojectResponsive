import React, { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBookOpen, faCheckCircle, faCircle, faHome } from '@fortawesome/free-solid-svg-icons';
import { faYoutube } from '@fortawesome/free-brands-svg-icons';
import { Link, useNavigate } from 'react-router-dom';
import DashboardPopup from '../math-genius/DashboardPopup'; // Import the DashboardPopup component
import "./side-nav-math-kbc.css";
import QuizCalculatorMultiChoice from './QuizCalculatorMultiChoice';
import QuizCalculatorMugal from './QuizCalculatorMugal';
import ModernHistory from './ModernHistory';
import FamousScientists from './FamousScientists';
import GeographyKbc from './GeographyKbc';
import GeographyRiver from './GeographyRiver';
import IndianConstitution from './IndianConstitution';
import PhysicsLaws from './PhysicsLaws';
import BiologicalKbc from './BiologicalKbc';
import OrderQuizApp from './OrderQuizApp';
import QuizArrangeLevel1 from './QuizArrangeLevel1';
import OrderQuizAppLevel2 from './OrderQuizAppLevel2';
import OrderQuizAppLevel3 from './OrderQuizAppLevel3';
import OrderQuizAppLevel4 from './OrderQuizAppLevel4';
import OrderQuizAppLevel5 from './OrderQuizAppLevel5';
import QuizmatchColumn from './QuizmatchColumn';
import QuizmatchColumnLevelTwo from './QuizmatchColumnLevelTwo';
import QuizmatchColumnLevelThree from './QuizmatchColumnLevelThree';
import QuizmatchColumnLevelFour from './QuizmatchColumnLevelFour';
import QuizmatchColumnLevelFive from './QuizmatchColumnLevelFive';
import QuizmatchColumnLevelSix from './QuizmatchColumnLevelSix';
import Pythagorean from './Pythagorean';
import Chemistry from './kbc-level-two/Chemistry';
import NobelPrizewinner from'./kbc-level-two/NobelPrizewinner';
import FamousAuther from './kbc-level-two/FamousAuther';
import Sports from './kbc-level-two/Sports';
import ClassicalDances from './kbc-level-two/ClassicalDances';
import MajorGlobalEvents from './kbc-level-two/MajorGlobalEvents';
import WorldMap from './WorldMap';
import WorldMapStatewise from './WorldMapStatewise';


function AppSideNavKBC() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSection, setExpandedSection] = useState(null); // Track expanded section
  const [completedCourses, setCompletedCourses] = useState(["0-0"]); // Track completed courses, including the first one by default

  const navigate = useNavigate();

  const [activeContent, setActiveContent] = useState({
    sectionIndex: 0,
    contentIndex: 0,
    title: "Ancient Indian History - Harappan Civilization (KBC 2000)",
    icon: faYoutube,
    video: "",
  });
  //const [completedCourses, setCompletedCourses] = useState([]); // Track completed courses
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const handlePopupOpen = () => {
    setIsPopupOpen(true); // Open popup
  };

  const handlePopupClose = () => {
    setIsPopupOpen(false); // Close popup
  };

  const handleConfirmNavigation = async () => {
    handlePopupClose(); // Close the popup
    try {
      navigate('/dashboard'); // Redirect to dashboard
    } catch (error) {
      console.error("Error navigating to dashboard:", error);
    }
  };

  const sections = [
    {
      title: "Historical and Cultural Activities && Current Affairs and Science Activitie",
      content: [
        { label: "Ancient Indian History - Harappan Civilization (KBC 2000)", video: "", icon: faYoutube },          
        { label: "Mughal Emperors and their Contributions (KBC 2001)", video: "", icon: faYoutube },          
        { label: "Modern History - Indian Independence Movement (KBC 2002)", video: "", icon: faYoutube },          
        { label: "Famous Scientists and their Inventions (KBC 2003)", video: "", icon: faYoutube },          
        { label: "Geography: World All States and their Capitals (KBC 2004)", video: "", icon: faYoutube },          
        { label: "World Geography:Currency,Language,Famous for, Rivers, Mountains, and Deserts (KBC 2005)", video: "", icon: faYoutube },          
        { label: "Constitution of India: Important Articles (KBC 2006)", video: "", icon: faYoutube },          
        { label: "Science: Basic Physics Laws - Newton's Laws && All Law (KBC 2007)", video: "", icon: faYoutube },          
        { label: "Biology: Human Anatomy - Digestive System (KBC 2008)", video: "", icon: faYoutube },          
        { label: "Mathematics: Pythagorean Theorem and Applications (KBC 2009)", video: "", icon: faYoutube },          

        
               
       

      ]
    },
    {
      title: "KBC Pre Level 2",
      content: [
        { label: "Chemistry: Periodic Table Elements and their Properties (KBC 2010)", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Current Affairs: Recent Nobel Prize Winners (KBC 2011)", video: "", icon: faYoutube },     
        { label: "Famous Indian Authors, All Authors, and their Works (KBC 2012)", video: "", icon: faYoutube },     
        { label: "Sports: Cricket World Cup Winners by Year (KBC 2013)", video: "", icon: faYoutube },     
        { label: "Indian Classical Dances and Their Origins (KBC 2014)", video: "", icon: faYoutube },     
        { label: "Current Affairs: Major Global Events - Olympics (KBC 2015)", video: "", icon: faYoutube },     

        

       
      ]
    },
    {
      title: "KBC Pro Level 3",
      content: [
        { label: "Content 3A", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Content 3B", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
      ]
    },
    {
      title: "KBC Arrange Order Question ( Practice Questions ) ",
      content: [
      
       
        { label: "Arrange Order Question", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Arrange Order Question Level One", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Arrange Order Question Level Two", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Arrange Order Question Level Three", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Arrange Order Question Level Four", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Arrange Order Question Level Five", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },


       
      ]
    },
    {
      title: "KBC Match Order  Question ( Practice Questions ) ",
      content: [
      
       
        { label: "Match Order Question level One", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Match Order Question level Two", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Match Order Question level Three", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Match Order Question level Four", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Match Order Question level Five", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Match Order Question level Six", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },

        
      ]
    },
    {
      title: "World Map with Country Area Tooltip ( Practice Questions ) ",
      content: [
      
       
        { label: "World Map with Country Area Tooltip", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },
        { label: "Interactive India States Map", video: "https://www.w3schools.com/html/mov_bbb.mp4", icon: faYoutube },

       
        
      ]
    }


   // QuizmatchColumn

  ];

  const toggleSidebar = () => setIsExpanded(!isExpanded);

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const handleContentClick = (sectionIndex, contentIndex, content) => {
    setActiveContent({
      sectionIndex,
      contentIndex,
      title: content.label,
      icon: content.icon,
      video: content.video,
    });

    if (!completedCourses.includes(`${sectionIndex}-${contentIndex}`)) {
      setCompletedCourses([...completedCourses, `${sectionIndex}-${contentIndex}`]);
    }
  };

  return (
    <> 
     <div className="app-container">
      <div className={`sidebar-math ${isExpanded ? "expanded" : "collapsed"}`}>
        <div className="tutor-tabs-btn-group">
          <a href="#tutor-lesson-sidebar-tab-content">
            <FontAwesomeIcon style={{ color: '#ff5248' }} icon={faBookOpen} />
            <span className="Lesson-title"> Lesson List</span>
          </a>
        </div>

        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="section">
            <div className="section-title" onClick={() => toggleSection(sectionIndex)}>
              <FontAwesomeIcon /> {section.title} <span className="expend-icon-penal"> {expandedSection === sectionIndex ? "-" : "+"} </span>
            </div>
            {expandedSection === sectionIndex && (
              <div className="section-content tutor-lessons-under-topic">
                <ul>
                  {section.content.map((item, contentIndex) => (
                    <li
                      key={contentIndex}
                      className={`content-item ${activeContent.sectionIndex === sectionIndex && activeContent.contentIndex === contentIndex ? "active-content" : ""}`}
                    >
                      <a href="#!" onClick={() => handleContentClick(sectionIndex, contentIndex, item)} className="content-link">
                        <div className="content-info">
                          <div className="content-left">
                            <FontAwesomeIcon icon={item.icon} style={{ marginRight: "8px" }} />
                            <span>{item.label}</span>
                          </div>
                          <div className="content-right">
                            <span className="content-timing">120:M</span>
                            <FontAwesomeIcon
                              icon={completedCourses.includes(`${sectionIndex}-${contentIndex}`) ? faCheckCircle : faCircle}
                              className="completion-icon"
                            />
                          </div>
                        </div>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="content-side-bar">
        <div className="video-player-header">
          <button className="toggle-btn" onClick={toggleSidebar}>
            {isExpanded ? ">" : "<"}
          </button>
          {/* Home Icon and Go to Home Message */}
          <span  onClick={handlePopupOpen} className="go-home">
            <FontAwesomeIcon icon={faHome} />  Go to Course Dashboard
          </span>
          <span className="header-title-side-bar">
            <h3><FontAwesomeIcon icon={activeContent.icon} /> {activeContent.title}</h3>
          </span>
        </div>
        {/* <video src={activeContent.video} controls width="100%" autoPlay /> */}
        
        {/* Conditionally show QuizCalculatorMulti if "The Beauty of 11" is selected */}
        {activeContent.title === "Ancient Indian History - Harappan Civilization (KBC 2000)" && <QuizCalculatorMultiChoice />}
        {activeContent.title === "Mughal Emperors and their Contributions (KBC 2001)" && <QuizCalculatorMugal />}
        {activeContent.title === "Modern History - Indian Independence Movement (KBC 2002)" && <ModernHistory />}
        {activeContent.title === "Famous Scientists and their Inventions (KBC 2003)" && <FamousScientists/>}
        {activeContent.title === "Geography: World All States and their Capitals (KBC 2004)" && <GeographyKbc/>}
        {activeContent.title === "World Geography:Currency,Language,Famous for, Rivers, Mountains, and Deserts (KBC 2005)" && <GeographyRiver/>}
        {activeContent.title === "Constitution of India: Important Articles (KBC 2006)" && <IndianConstitution/>}
        {activeContent.title === "Science: Basic Physics Laws - Newton's Laws && All Law (KBC 2007)" && <PhysicsLaws/>}
        {activeContent.title === "Biology: Human Anatomy - Digestive System (KBC 2008)" && <BiologicalKbc/>}
        {activeContent.title === "Mathematics: Pythagorean Theorem and Applications (KBC 2009)" && <Pythagorean/>}
        {activeContent.title === "Chemistry: Periodic Table Elements and their Properties (KBC 2010)" && <Chemistry/>}
        {activeContent.title === "Current Affairs: Recent Nobel Prize Winners (KBC 2011)" && <NobelPrizewinner/>}
        {activeContent.title === "Famous Indian Authors, All Authors, and their Works (KBC 2012)" && <FamousAuther/>}
        {activeContent.title === "Sports: Cricket World Cup Winners by Year (KBC 2013)" && <Sports/>}
        {activeContent.title === "Indian Classical Dances and Their Origins (KBC 2014)" && <ClassicalDances/>}
        {activeContent.title === "Current Affairs: Major Global Events - Olympics (KBC 2015)" && <MajorGlobalEvents/>}

        
        
       
       
      
      
        
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
        {activeContent.title === "Arrange Order Question" && <OrderQuizApp/>}
        {activeContent.title === "Arrange Order Question Level One" && <QuizArrangeLevel1/>}
        {activeContent.title === "Arrange Order Question Level Two" && <OrderQuizAppLevel2/>}
        {activeContent.title === "Arrange Order Question Level Three" && <OrderQuizAppLevel3/>}
        {activeContent.title === "Arrange Order Question Level Four" && <OrderQuizAppLevel4/>}
        {activeContent.title === "Arrange Order Question Level Five" && <OrderQuizAppLevel5/>}

        {activeContent.title === "Match Order Question level One" && <QuizmatchColumn/>}
        {activeContent.title === "Match Order Question level Two" && <QuizmatchColumnLevelTwo/>}
        {activeContent.title === "Match Order Question level Three" && <QuizmatchColumnLevelThree/>}
        {activeContent.title === "Match Order Question level Four" && <QuizmatchColumnLevelFour/>}
        {activeContent.title === "Match Order Question level Five" && <QuizmatchColumnLevelFive/>}
        {activeContent.title === "Match Order Question level Six" && <QuizmatchColumnLevelSix/>}


        {activeContent.title === "World Map with Country Area Tooltip" && <WorldMap/>}
        {activeContent.title === "Interactive India States Map" && <WorldMapStatewise/>}


        
        
        
        
       
       
        
      </div>

    </div>
     {/* Render Popup if it's open */}
     {isPopupOpen && (
            <DashboardPopup 
              onClose={handlePopupClose} 
              onConfirm={handleConfirmNavigation} 
            />
          )}

  </>
   
  );
}

export default AppSideNavKBC;
