/**
 * Copyright 2015 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var express = require('express'); // app server
var bodyParser = require('body-parser'); // parser for post requests
var AssistantV2 = require('ibm-watson/assistant/v2'); // watson sdk
const { IamAuthenticator, BearerTokenAuthenticator } = require('ibm-watson/auth');
var cors = require('cors')

var https = require('https');
//const tunnel = require('tunnel');
var HttpsProxyAgent = require('https-proxy-agent');
var agent = new HttpsProxyAgent('https://na9-s500-1:8080');

var app = express();
app.use(cors())

// Bootstrap application settings
app.use(express.static('./public')); // load UI from public folder
app.use(bodyParser.json());

// Create the service wrapper

let authenticator;
if (process.env.ASSISTANT_IAM_APIKEY) {
  console.log('iam api key>>>>', process.env.ASSISTANT_IAM_APIKEY)
  authenticator = new IamAuthenticator({
    apikey: process.env.ASSISTANT_IAM_APIKEY
  });
} else if (process.env.BEARER_TOKEN) {
  authenticator = new BearerTokenAuthenticator({
    bearerToken: process.env.BEARER_TOKEN
  });
}


var assistant = new AssistantV2({
  version: '2019-02-28',
  authenticator: authenticator,
  url: process.env.ASSISTANT_URL,
  disableSslVerification: true
});

var newContext = {
  global : {
    system : {
      user_id:"D-Wjsoo2Rd7d_uSb-jMUdb0U7gQvNpSR0xdP4C4C23je",
    }
  },
  skills: {
    "main skill": {
       user_defined: {
         account_number:"123456"
        }
     }
  }
};

// Endpoint to be call from the client side
// app.post('/api/message', function (req, res) {
//   var username="apikey";
//   var passw=process.env.ASSISTANT_IAM_APIKEY;
//   var assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
//   if (!assistantId || assistantId === '<assistant-id>>') {
//     return res.json({
//       'output': {
//         'text': 'The app has not been configured with a <b>ASSISTANT_ID</b> environment variable. Please refer to the ' + '<a href="https://github.com/watson-developer-cloud/assistant-simple">README</a> documentation on how to set this variable. <br>' + 'Once a workspace has been defined the intents may be imported from ' + '<a href="https://github.com/watson-developer-cloud/assistant-simple/blob/master/training/car_workspace.json">here</a> in order to get a working application.'
//       }
//     });
//   }
//   var contextWithAcc = (req.body.context) ? req.body.context : newContext;

//   if (req.body.context) {
//     contextWithAcc.global.system.turn_count += 1;
//   }

//   //console.log(JSON.stringify(contextWithAcc, null, 2));

//   var textIn = '';

//   if(req.body.input) {
//     textIn = req.body.input.text;
//   }

//   var payload = {
//     input: {
//       message_type : 'text',
//       text : textIn,
//       options : {
//         return_context : true
//       }
//     },
//     context: contextWithAcc
//   };

//   //console.log('session '+req.body.session_id);
//   //console.log('assistant Id '+process.env.ASSISTANT_ID);
//   console.log('payload '+JSON.stringify(payload));
//   return new Promise((resolve,reject) => 
//     {
//         try
//         {
//           /*let output = '';
//             https.request({
//               host: 'gateway.watsonplatform.net',
//               port: 443,
//               method: 'POST',
//               path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions/'+req.body.session_id+'/message?version=2019-02-28',
//               headers: {
//                 "Authorization": "Basic " + new Buffer(username + ':' + passw).toString('base64'),
//                 "Content-Type": "application/json",
                
//                 },
//                 //body: JSON.stringify(payload),
//               /*  body:payload,
//                 agent: agent,
            
//             }, function (resp) {
//               //console.log(resp);
//               resp.on('data', function (data) {
//                 console.log("resp");
//                 console.log(data.toString());
//                 output+=data;
//                 //resolve(res.send(data.toString()));
//                 });
//                 resp.on('end', function() {
//                   //console.log("resp");
//                   console.log(output.toString());
//                   console.log(JSON.parse(output).explanation);
//                   resolve(res.send(output.toString()));
//                   })
//             }).end();*/

//             var options = {
//               host: 'gateway.watsonplatform.net',
//               port: 443,
//               method: 'POST',
//               path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions/'+req.body.session_id+'/message?version=2019-02-28',
//               headers: {
//                 "Authorization": "Basic " + new Buffer(process.env.ASSISTANT_USERNAME + ':' + process.env.ASSISTANT_IAM_APIKEY).toString('base64'),
//                 "Content-Type": "application/json",
//               },
//               agent: agent
//             };

            // let data = "";
            // let apiRequest = https.request(options, function(result) {
            //   console.log("Connected--1"+result);
            //   result.on("data", chunk => {
            //     data += chunk;
            //   });
            //   result.on("end", () => {
            //     console.log("data collected"+data.toString());
            //     resolve(res.send(data.toString()));
            //     //res.end(JSON.stringify(data));
            //   });
            // });
          
//             apiRequest.end();

//           }
//           catch(error) 
//           {
//               reject(error);
//           }
//       });
// });

// app.get('/api/session', function (req, res) {
//   console.log('req ', req.body)
//   return new Promise((resolve,reject) => 
//     {
//         try
//         {
//             /*https.request({
//               // like you'd do it usually...
//               host: 'gateway.watsonplatform.net',
//               port: 443,
//               method: 'POST',
//               path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions?version=2019-02-28',
//               headers: {
//                 "Authorization": "Basic " + new Buffer(username + ':' + passw).toString('base64'),
//                 "Content-Type": "application/json",
//                 },
//              agent: agent
//             }, function (resp) {
//                   resp.on('data', function (data) {
//                   console.log(data.toString());
//                   resolve(res.send(data.toString()));
//             });
//             }).end();*/

//            // let url = process.env.URL+process.env.ASSISTANT_ID+'/sessions?version='+process.env.VERSION_DATE;
//            console.log('before options<<<<<')
//            var options = {
//               host: 'gateway.watsonplatform.net',
//               port: 443,
//               method: 'POST',
//               path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions?version=2019-02-28',
//               headers: {
//                 "Authorization": "Basic " + new Buffer(process.env.ASSISTANT_USERNAME + ':' + process.env.ASSISTANT_IAM_APIKEY).toString('base64'),
//                 "Content-Type": "application/json",
//               },
//               agent: agent
//             };
//             console.log('after options<<<<<', options)

//             let data = "";
//             let apiRequest = https.request(options, function(result) {
//               console.log("Connected");
//               result.on("data", chunk => {
//                 data += chunk;
//               });
//               result.on("end", () => {
//                 console.log("data collected"+data.toString());
//                 resolve(res.send(data.toString()));
//                 //res.end(JSON.stringify(data));
//               });
//             });
//             apiRequest.end();
//           }
//           catch(error) 
//           {
//             console.log('errrrrrrrererererer>>>>>>', error)
//               reject(error);
//           }
//       });
// });
app.get('/api/session', function (req, res) {
  console.log('req.body>>', req.body)
  console.log('process.env.ASSISTANT_ID>>', process.env.ASSISTANT_ID)
  console.log('assistant<<<<<>>', assistant)

  assistant.createSession(
    {
      assistantId: process.env.ASSISTANT_ID || '{assistant_id}',
    },
    function (error, response) {
      if (error) {
        console.log(error, 'error>>>>>>>>>>>??????????????????')
        return res.send(error);
      } else {
        console.log(response, 'response>>>>>>>>>>>??????????????????')
        //  let data = ""
        // return res.send(response);
        // response.on("data", chunk => {
        //   data += chunk;
        // });
        // response.on("end", () => {
        //   console.log("data collected"+data.toString());
        //   resolve(res.send(data.toString()));
        //   //res.end(JSON.stringify(data));
        // });
        return res.send(response)
      }
    }
  );
});
app.post('/api/message', function (req, res) {
  console.log('/////', req.body)
  let assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
  if (!assistantId || assistantId === '<assistant-id>') {
    return res.json({
      output: {
        text: "Error"

      }
    });
  }
  // console.log(req.body, 'llll')

  var textIn = req.body.input.text ? req.body.input.text : '';

  // var token = req.body.token ? req.body.token : ""
  var payload = {
    assistantId: assistantId,
    sessionId: req.body.session_id,

    input: {
      message_type: 'text',
      text: textIn,
    },
  };

  console.log('Payloead>>>>>>>',payload)
  // let userdata = {
  //   token: req.body.token,
  //   userid: req.body.userid,
  //   userName: req.body.userName
  // }
  // console.log(userdata, 'assistant userdata++++++++++')
  // Send the input to the assistant service
  assistant.message(payload, function (err, data) {
    if (err) {
      console.log(err, 'err')
      const status = err.code !== undefined && err.code > 0 ? err.code : 500;
      return res.status(status).json(err);
    }
    

    // console.log('data.result.output>>>>>>>>+++++', JSON.stringify(data.result))
    // let data = ""
    // result.result.on("data", chunk => {
    //   data += chunk;
    // });
    // result.result.on("end", () => {
    //   console.log("data collected"+data.toString());
    //   resolve(res.send(data.toString()));
    //   //res.end(JSON.stringify(data));
    // });


// console.log('ata.result.output.generic[0].text>>>>>>', data.result.output.generic[0].text)
    // data.result.output.generic[0].type = "simple"
    // return res.json(data.result.output.generic[0].text.toString());
    return res.json(data.result);
    console.log('yaha ro nai aaya', data.result.output.generic[0].text)

    if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Highest_Score") {
      UserScoreAccType(res, userdata.token, userdata.userid, 'high')
    }
    else if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Lowest_Score") {
      UserScoreAccType(res, userdata.token, userdata.userid, 'low')


    }
    else if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Weak_Point") {
      UserCategoryReportType(res, userdata.token, userdata.userid, 'weak')


    }
    else if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Strong_Point") {
      UserCategoryReportType(res, userdata.token, userdata.userid, 'strong')


    }
    else if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Quiz_Details") {

      // console.log('&&&&&&&7777777777777777777777')
      return res.json([{ type: 'details' }]);


    }
    else if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Category_Details") {

      // console.log('&&&&&&&7777777777777777777777')
      return res.json([{ text: 'category', type: 'categoryform' }]);


    }
    else if (data.result.output && data.result.output.intents.length > 0 && data.result.output.intents[0].intent == "Last_Assessment") {

      return res.json([{ text: 'last' }]);


    }
    else {
      // console.log("bot response++++", data.result.output)
      data.result.output.generic[0].type = "simple"
      return res.json(data);
    }
  });
});
module.exports = app;
//module.exports = logger;
