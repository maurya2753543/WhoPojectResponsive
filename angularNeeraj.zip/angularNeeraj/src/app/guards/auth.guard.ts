import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

import { AppConfig } from '../config/app.config';
import { WebStorage } from '../utility/web.storage';

import { AuthService } from '../services/auth.service';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
      
        private router: Router,
        private auth: AuthService,
        // private storage: WebStorage,
        // private tmpStorage: TmpStorage
    ) { }
    

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      
        if(this.auth.isAuth()){
            return true;
        }
        else {
            this.router.navigate(['/login'])
        }
    }

 
     
}