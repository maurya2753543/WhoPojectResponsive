import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminBotReportDetailComponent } from './admin-bot-report-detail/admin-bot-report-detail.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './guards/auth.guard';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path : 'login', component : LoginComponent},
  {path : 'dashboard', component : DashboardComponent, canActivate: [AuthGuard]},
  {path: 'dashboard/admin-bot-report/:role', component: AdminBotReportDetailComponent, canActivate: [AuthGuard]},

  // {path : 'dashboard', component : HeaderComponent},

  {path : '**', redirectTo: '/login', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
