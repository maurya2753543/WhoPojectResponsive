import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { FormGroup, FormArray, FormBuilder, Validators, NgForm } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent  {
  public userLogin: FormGroup;
  public loading = false;
  constructor(
    private formbuilder: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private toastr: ToastrService



  ) {
    this.userLogin = formbuilder.group({
      username: [""],
      password:[""]
    });
   }
     login(){
      console.log('this user ', this.userLogin.value)
      this.loading = true;
      if(this.userLogin.valid){
        this.userLogin.value.username = this.userLogin.value.username.trim(); 
        this.auth.login(this.userLogin.value).subscribe((res: any) => {
         if(res.success){
          // alert('login success')
          this.loading = false;
          this.toastr.success('Logged in successfully');
          this.router.navigate(["dashboard"]);

         }else {
          // alert(res.message)
          this.loading = false;
          this.toastr.error(res.message);

         }
        }, (err)=>{
          this.toastr.error(err);
          this.loading = false;


          // alert('Internal Server Error')
        });
      }
      this.loading = false;

     }
  ngOnInit(): void {
  }

}
