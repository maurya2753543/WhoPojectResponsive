import { Injectable } from "@angular/core";
// import { HttpHeaders as Headers } from "@angular/common/http";
//import { Headers } from '@angular/http';
var baseApiUrl = "http://localhost:3000";
var apiUrl = "http://localhost:3000/api";

//Dynamically change BASE and API URL
//For staging

if (window.location.origin !== "http://localhost:4200") {
  var baseApiUrl = "https://eva-healthcare-bot.mybluemix.net"; // 
  var apiUrl = "https://eva-healthcare-bot.mybluemix.net" + "/api"; // 
}




@Injectable()
export class AppConfig {
  clientUrl = window.location.origin;
  withoutLoginUrls: any = ["login"];
  baseApiUrl: any = "https://eva-healthcare-bot.mybluemix.net";
  // baseApiUrl: any = "http://localhost:3000";



  // apiUrl: any = (['localhost', '127.0.0.1'].indexOf(window.location.hostname)!== -1) ? "http://localhost:5115/api/v1" : "http://52.34.207.5:5115/api/v1";
 
 
 
 
  apiUrl: any = "https://eva-healthcare-bot.mybluemix.net" + "/api";
  // apiUrl: any = "http://localhost:3000" + "/api";

  assetPath: any = "assets";
  perPageDefault: any = 5;
  statusCode: any = {
    error: 409,
    success: 200,
    success1: 201,
    badRequest: 400,
    unauthorized: 401,
    notFound: 404,
    forbidden: 403,
    invalid: 406,
    serviceUnavailable: 503,
    continue: 100
  };

  
  imagePaths: any = {
    'uploadSpinner': '/assets/spinner/fileUpload.gif'
  }


}
