import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class WebStorage {

  private locStorage:any;
  private sesStorage:any;
  
  public currentUser = new BehaviorSubject({userName :'',role:'',profileImagePath:''});


  constructor() {
    this.locStorage  = window.localStorage;
    this.sesStorage  = window.sessionStorage;
      if(this.get('user'))
      {
        try {
             let user = JSON.parse(this.get('user'));
             this.currentUser.next(user);           
          } catch (e) {
        }
      }
   }

   
   getUserDetails(){
    //console.log("getting user details"); 
    let userDetails = JSON.parse(this.get('user'));
    return userDetails;
   }

   setUserDetails(user){
    let user1 = {
      username : user.username,
      role : user.role,
    } 
    this.localStore(
      "user",JSON.stringify(user1)
    );
    let updatedUser = JSON.parse(this.get('user'));

    this.currentUser.next(updatedUser)
    

    this.localStore("role", user.role); 
    }

  get(key: any) {
    let localData = this.locStorage.getItem(key);
    let lData = (this.notEmpty(localData)) ? localData : '';
    return lData;
  }

  localStore(key: any, value: any) {
    this.clear(key);
    //let data = { value: value };
    //let val = JSON.stringify(data);
    this.locStorage.setItem(key, value);
  }

  sessionStore(key: any, value: any) {
    this.clear(key);
    let data = { value: value };
    let val = JSON.stringify(data);
    this.sesStorage.setItem(key, val);
  }

  clear(key: any) {
    this.locStorage.removeItem(key);
    this.sesStorage.removeItem(key);
  }

  exists(key: any) {
    if (this.get(key) != null) {
      return true;
    } else {
      return false;
    }
  }

  private notEmpty(data: any) {
    var res = true;
    var dataType = typeof data;
    switch (dataType) {
      case 'object':
        if (data == null || data.length < 1)
          res = false;
        break;

      case 'undefined':
        res = false;
        break;

      case 'number':
        if (data == "")
          res = false;
        break;
      case 'string':
        if (data.trim() == "")
          res = false;
        break;
    }

    return res;
  }
}