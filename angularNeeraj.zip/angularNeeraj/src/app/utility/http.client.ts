
import {Injectable} from '@angular/core';
import { HttpClient as Http,HttpHeaders } from '@angular/common/http';

//import {Http, Headers, URLSearchParams} from '@angular/comman/http';
// import { Router } from '@angular/router';
import { Observable } from 'rxjs';

import { WebStorage } from './web.storage';
import { AppConfig } from '../config/app.config';

@Injectable()
export class HttpClient {

  constructor(
    private http: Http,
    // private router: Router,
    private config: AppConfig,
    private storage: WebStorage
  ) {}
  
getHeaders(){
  let headers = new HttpHeaders({'Content-Type': 'application/json', "Authorization": "Bearer "+ localStorage.getItem("token")})
  return headers;
}
  createAuthorizationHeader(headers: HttpHeaders) {
    headers.append('Content-Type', 'application/json; charset=utf-8');
    headers.append('Authorization', 'Bearer ' + this.storage.get('token'));
  } 

  get(url:any, data:any, fullUrl?:boolean) {
    fullUrl = fullUrl||false;
    let headers = new HttpHeaders();
    this.createAuthorizationHeader(headers);
    let options:any = {
      headers: headers
    };
    options.params = data;
    let reqUrl = (fullUrl)?url:this.config.apiUrl+url;
    return this.http.get(reqUrl, options)
  }

  post(url:any, data:any, fullUrl?:any,contentType?:any) { 
    console.log('url>>>>', url)
    console.log('fullUrl>>>>', fullUrl)

    fullUrl = fullUrl || false;
    let headers:any = new Headers();
    this.createAuthorizationHeader(headers);
    console.log('fullUr2l>>>>', fullUrl)
    console.log('this.config.apiUrl', this.config.apiUrl)
    let reqUrl = (fullUrl)?url:this.config.apiUrl+url;
    console.log('>>>>>>', reqUrl)
    let options:any = {
      headers: headers
    };


    return this.http.post(reqUrl, data, {headers: this.getHeaders()});    
  }

  extractData(res: any) {
    let body = res;
    return body.data || { };
  }

  handleError (error: any) {
    let errMsg: string= error.message ? error.message : error.toString();
    //console.error(errMsg);
    return Observable.throw(errMsg);
  }

  ///Http request handler for expecting files in response
  getFile(url:any, data:any){
    let headers = new HttpHeaders();
    this.createAuthorizationHeader(headers);
    let options:any = {
      headers: headers
    };
    options.params = data;
    options.responseType = 'blob'; 
    let reqUrl = this.config.apiUrl+url;
    return this.http.get(reqUrl, options)
  }
}