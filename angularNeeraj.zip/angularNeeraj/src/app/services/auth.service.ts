import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
// import 'rxjs/add/operator/map';
// import 'rxjs/add/observable/of';
// import 'rxjs/add/operator/do';
// import 'rxjs/add/operator/delay';
import { of } from "rxjs";
import { catchError, map } from "rxjs/operators";
import { WebStorage } from "../utility/web.storage";
import { AppConfig } from "../config/app.config";
import { HttpClient } from "../utility/http.client";
import { HttpErrorResponse, HttpHeaders } from "@angular/common/http";
@Injectable()
export class AuthService {
  isLoggedIn = false;

  constructor(
    private http: HttpClient,
    private storage: WebStorage
  ) {
    // this.getHeaders();
  }
// getHeaders(){
//   let headers = new HttpHeaders({'Content-Type': 'application/json', "Authorization": "Bearer "+ localStorage.getItem("token")})
//   console.log('heders>>>>>', headers) 
//   return headers;
// }
isAuth(){
  if(localStorage.token){
    return true;
  }
  else {
    return false;
  }
}


  checkLogin(): Observable<any> {
    return this.http.get("/users/checkUser", []);
  }

  login(data: any): Observable<any> {
    return this.http.post("/login", data).pipe(
      map((res: any) => {
        let body = res;
        if (body.code == 200) {
          this.storage.localStore("token", body.data.token);
          this.storage.setUserDetails(body.data.user);
        }
        return body;
      })
    );
  }

  getBotReport(data: any): Observable<any> {
    return this.http.post("/getBotReport", data)
    .pipe(
      map((res: any) => {
        this.handleError(res)
        let body = res;
        return body;
      })
    );
  }
  getAllAdminIntents(data: any): Observable<any> {
    return this.http.post("/getAllAdminIntents", data)
    .pipe(
      map((res: any) => {
        this.handleError(res)
        let body = res;
        return body;
      })
    );
  }



  
  logout(): Observable<any> {
    this.storage.clear("token");
    this.storage.clear("user");
    this.storage.clear("role");
    this.isLoggedIn = false;
    return of({ status: true });
  }
  private handleError(error){
    console.log('err>>>.', error)
      if(error.code === "401"){
        this.logout();
      }
      return throwError(
        'Something bad happened; please try again later.'
      );
  }
}

