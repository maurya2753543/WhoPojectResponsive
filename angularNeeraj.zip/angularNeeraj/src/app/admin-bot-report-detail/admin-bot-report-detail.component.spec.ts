import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBotReportDetailComponent } from './admin-bot-report-detail.component';

describe('AdminBotReportDetailComponent', () => {
  let component: AdminBotReportDetailComponent;
  let fixture: ComponentFixture<AdminBotReportDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminBotReportDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminBotReportDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
