import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import {Router} from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import {ActivatedRoute} from '@angular/router'

@Component({
  selector: 'app-admin-bot-report-detail',
  templateUrl: './admin-bot-report-detail.component.html',
  styleUrls: ['./admin-bot-report-detail.component.scss']
})
export class AdminBotReportDetailComponent implements OnInit {
  public totalItems: any =0;
  p: Number = 1;
  paramRole: any;
  public loading = false;
  trackByMethod(index:number, el:any): number {
    return el.id;
  }
  constructor( private auth: AuthService,
    private router: Router,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute) { }
    public params: any = {
      'page': 1,
      'limit': 10
    }
    intentList: [];
    isIntentListExists: boolean = false;

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((param: any)=>{
      this.paramRole = param.role;
     if(param.role == 'allIntents'){
      this.getAllIntents();

     }
  })
  }
  logout(){
    this.auth.logout().subscribe((res: any) => {
      this.router.navigate(["/login"]);
    });
  }
  pageChange(event: any): void{
    this.params.page = event;
    this.p = event;
    if(this.paramRole == 'allIntents'){
      this.getAllIntents();
    }
  }
  
  getAllIntents(){
    // this.loader.open();
    this.loading = true;

    const obj = {
      'page': this.params.page,
      'limit': this.params.limit
    }
    
    this.auth.getAllAdminIntents(obj).subscribe(res => {
      if(res.code == 200){
         this.intentList = res.data;
         this.totalItems = res.count;
         if(this.intentList.length > 0){
           this.isIntentListExists = true;
         }
         else{
          this.isIntentListExists = false;
          }
      }
      // this.loader.close();
      this.loading = false;

    }, err => {
      // this.loader.close();
      this.loading = false;

    })
  }
}
