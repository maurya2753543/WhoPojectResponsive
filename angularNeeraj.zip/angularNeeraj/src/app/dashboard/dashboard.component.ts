import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import {Router} from "@angular/router";
import { Chart } from 'chart.js';
import { ToastrService } from 'ngx-toastr';
import { Angular2CsvModule } from 'angular2-csv';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dashboardData : any = [];
  BarChart: any;
  pieChart: any;
  lineChart: any;
  public loading = false;
  public startDate;
  public endDate;
  selectedDay: string = '';
  options: any;
  data: any =[];
  csvData: any = [];
  constructor(
    private auth: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {

   }

  ngOnInit(): void {
    // this.toastr.success('Hello world!', 'Toastr fun!');
    this.selectedDay = "past30Days";
    this.getBotReport();
    document.querySelector('angular2csv > button').innerHTML = 'Export to CSV';
    // document.querySelector('angular2csv > button').innerHTML = '<style>background-color: red<style>';

    // document.getElementById("export").innerHTML = "<button class='btn btn-primary' style='background-color: #89cff0';><span style='color: #333; font-weight:bold;'>Export csv</span></button>";

  }
  clear() {
    this.startDate = null;
    this.endDate = null;
    this.selectedDay = "past30Days";
    this.getBotReport();
  }
  selectChangeHandler(event: any) {
    //update the ui
    this.selectedDay = event.target.value;
    this.startDate = null;
    this.endDate = null;
    console.log('this selected day', this.selectedDay)
    this.getBotReport();

  }
  filterByDate() {

    if (this.startDate == undefined || this.endDate == undefined) {
      this.toastr.info('Please select both dates');
      return;
    }
    this.selectedDay = "";
    this.getBotReport();
  }
  logout(){
    this.auth.logout().subscribe((res: any) => {
      this.router.navigate(["/login"]);
    });
  }
  getBotReport() {
    this.loading = true;

    let reqObj = {
      startDate: this.startDate,
      endDate: this.endDate,
      selectedDay: this.selectedDay,
    }
    this.auth.getBotReport(reqObj).subscribe(async res => {
      
      if (res.code == 200) {
        this.loading = false;
        this.dashboardData = await res.data
        this.csvData = this.dashboardData.service.service
        console.log('this.dashboardData>>', this.csvData)
        this.options = {
          fieldSeparator: ',',
          quoteStrings: '"',
          decimalseparator: '.',
          showLabels: false,
          headers: ['Employee Id',
          'Main Service',
          'Employee Entity',
          'Selected Service',
          'Benificiary Name', 
          'Benificiary Phone',
          'City',
          'State',
          'Date of birth',
          'Chat Initiated By',
          'Chat Initiated For',
          'Gender',
          'Fever',
          'SpO2 Level',
          'Created At',
          'Origin',
          'Preferred Date',
          'Preferred Time',
          'Preferred Language',
          'Preferred State'],
          showTitle: false,
          title: '',
          useBom: false,
          removeNewLines: false,
          keys: [
      
     ]
        };
       this.data = [ ];
       this.csvData.forEach(element => {
             var selectedservice = ""
         if(element.parentService == 'Health Check'){
               selectedservice = element.healthCheck
         }
         if(element.parentService == 'Dental Procedures'){
          selectedservice = element.dentalProcedures
        }
        if(element.parentService == 'Care Plan'){
          selectedservice = element.carePlan
        }
        if(element.parentService == 'Dental Procedures'){
          selectedservice = element.dentalProcedures
        }
        if(element.parentService == 'Covid-19 ' &&  element.covidorNoncovid_service == 'Covid-19 Assistance'){
           element.parentService = "Covid-19 Assistance";
           selectedservice = element.selectedDovidService

        }
        if(element.parentService == 'Covid-19 ' &&  element.covidorNoncovid_service == 'Non-Covid 19 Assistance '){
          element.parentService = "Non-Covid 19 Assistance";
          selectedservice = (element.freeorDiscountedService == "Free Service" ? element.freeDentalorLifeCoach : element.discountedPriceService)
       }
         this.data.push({
           'Employee Id': element.empId ? element.empId : "-",
           'Main Service': element.parentService ? element.parentService : "-",
           'Employee Entity': element.employeEntity ? element.employeEntity : "-",
           'Selected Service': selectedservice ? selectedservice : "-",
           'Benificiary Name': element.beneficiaryName ? element.beneficiaryName : "-",
           'Benificiary Phone': element.beneficiaryNumber ? element.beneficiaryNumber : "-",
           'City': element.patientCity ? element.patientCity: "-",
           'State': element.patientState ? element.patientState: "-",
           'Date of birth': element.dob ? element.dob: "-",
           'Chat Initiated By': element.whoInitiatingChat ? element.whoInitiatingChat: "-",
           'Chat Initiated For': element.whomSeekingAssistance ? element.whomSeekingAssistance: "-",
           'Gender': element.patientGender ? element.patientGender: "-",
           'Fever': element.feverishYesorNo ? element.feverishYesorNo : "-",
           'SpO2 Level': element.spo2level ? element.spo2level : "-",
           'Created At': this.convertDate(element.created_at) ? this.convertDate(element.created_at) : "-",
           'Origin': element.origin ? element.origin : "-",
           'Preferred Date': element.PreferredDate ? element.PreferredDate : "-",
           'Preferred Time': element.preferredTime ? element.preferredTime : "-",
           'Preferred Language': element.PreferredLanguage ? element.PreferredLanguage : "-",
           'Preferred State': element.PrefferedState ? element.PrefferedState : "-",

         })
       });
    

        this.showBarChart(this.dashboardData);
        this.showPieChart(this.dashboardData);
        this.showLineChart(this.dashboardData);

      }
      // this.loader.close();
    }, err => {
      this.loading = false;

      // this.loader.close();
    })
  }
  
  showBarChart(dashboardData) {

    if (this.BarChart) {
      this.BarChart.destroy()
    }
    this.BarChart = new Chart('barChart', {
      type: 'bar',
      data: {
        labels: dashboardData.barchartData.categoryArray,
        datasets: [{
          label: 'Service',
          data: dashboardData.barchartData.categoryCount,
          backgroundColor: '#0254a3',

          borderColor: '#0254a3',
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "",
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  }
  showPieChart(dashboardData) {
    
    if (this.pieChart) {
      this.pieChart.destroy()
    }
    this.pieChart = new Chart('pieChart', {
      type: 'pie',
      data: {
        labels: dashboardData.barchartData.categoryArray,
        datasets: [{
          label: 'Service',
          data: dashboardData.barchartData.categoryCount,
          backgroundColor: [
            '#0254a3','#4169E1','#89cff0', '#bcd4e6'

          ],
          borderColor: [
            '#0254a3', '#4169E1','#89cff0', '#bcd4e6'

          ],
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "",
          display: true
        },
        // scales: {
        //   yAxes: [{
        //     ticks: {
        //       beginAtZero: true
        //     }
        //   }]
        // }
      }
    });
  }
  showLineChart(dashboardData) {
    if (this.lineChart) {
      this.lineChart.destroy()
    }
    this.lineChart = new Chart('lineChart', {
      type: 'line',
      data: {
        labels: dashboardData.lineChartData.dateArray,
        datasets: [{
          label: 'Appointments',
          data: dashboardData.lineChartData.inputMessageCountArray,
          // backgroundColor: [
          //   '#536a1b'
          // ],
          borderColor: [
            '#007bff'
          ],
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "Appointments(last 30 occurances)",
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: false
            }
          }]
        }
      }
    });
  }
   convertDate(inputFormat) {
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat)
    return [pad(d.getDate()), pad(d.getMonth()+1), d.getFullYear()].join('/') + ','+d.toLocaleTimeString()
  }
  
}
